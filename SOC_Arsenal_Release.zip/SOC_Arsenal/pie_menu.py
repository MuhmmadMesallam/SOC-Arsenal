# SOC Arsenal Universal Protected — pie_menu
# Copyright (c) 2026 SOC Arsenal. All rights reserved.
import sys, os, zlib, base64, importlib.machinery, importlib.util

def _init_module():
    _dir = os.path.dirname(os.path.abspath(__file__)) if '__file__' in globals() else os.path.abspath(".")
    _so_candidates = [
        os.path.join(_dir, f"pie_menu{ext}") for ext in importlib.machinery.EXTENSION_SUFFIXES
    ] + [
        os.path.join(_dir, "pie_menu.so"),
        os.path.join(_dir, "pie_menu.dylib"),
        os.path.join(_dir, "pie_menu.pyd"),
    ]
    _so_file = next((f for f in _so_candidates if os.path.exists(f)), None)
    
    if _so_file:
        try:
            loader = importlib.machinery.ExtensionFileLoader("pie_menu", _so_file)
            spec = importlib.util.spec_from_loader("pie_menu", loader)
            mod = importlib.util.module_from_spec(spec)
            sys.modules["pie_menu"] = mod
            loader.exec_module(mod)
            globals().update({k: getattr(mod, k) for k in dir(mod) if not k.startswith("__")})
            return
        except Exception:
            pass
            
    # Universal encrypted bytecode execution (Windows / Mac / Linux)
    _key = 2
    _payload = "df4Y%-)-465`FDmqdyLlR8?`_CU1yjg3%;jvwS*qvOYG4!b*-$MkF_gNUneW?YSXmi<V|3Tlq8rl&87j-%aN8JZiMghF08=s>hLOE0o-(K2ZhZo48`jo~YhoMB>gqxiD>prniC^dRzO2n6o=2>%uvi&|06k@a+gxiA@UOh)5ECAy9+85y<0sE{T2vy`_MuLoYN#eof$(=DRgx_95qoT|)?5Kl9>2V8;fHaF~E!n0iGN7(G=m(opR^e>j^&(ewNH%_1`n^+cHd^k)9lpzMsCYH&cUzbas!t19qA@%O@!CSyl@wz<7s+s92@W>)w^TFC?t2}Flv5~?&cEHR}r)jkt-r7N4|{F?~R;d`6Y@>Y;1zEhkT*sU@f+})fhVQgiHmiuLVEU;Xoi^_;D>RKErC)-z}s<VmlTamztb9O8X&CwvFULTSAWGqL+k*t_ew4lq5|4V=Qe|_*o0j)>sjQ=W#o`9eFg!8+7ED6|?BQRV>*bO>YQ=G7xz-Iin!H}O-+)RnRG4ga!a7R(*&o=Fly|tRVAW#Ew3iXzuh(W%O(+}gr`k_789eR24KZ5OQZ5o2cK;BRrx8`E%EXa?X;RoK}9Th)%E&++YiMixDip4bdb5flRwL#xOt}Ww$-5jbLlRNLi)>Z}J1}l~Rftuws%E1Juw9tgR1>CX?_JPy?F}R5eb%hyZ_M~MjZQfg+|MVJaxh(@2&f<yV|I%FUZG<$Xz5x$vRuD%aOEd60GTm3cNj$HcY0d<y13!4v0T|_Q{pZ0#ZJEtFz3+lFTA`^h0IUJq0>9=}r}bp?`Jn<K4|NO7^fba4s)XJRTC)sXx004B9|2GW?7L)|0+QHj4?uzR`$G*_u}i4!e`@upFWQ0hs7kr~Xo@rA4BBC$T<}{*d@|7gqnpwB9%B_>UWKdQe5!aBPauTr@sZ-zNP&)lsYFl(dMWoys0hnhQ(Qe;tJF}DQjk7GNs*f`CkdpecAksgP!X*HbzZ>7&{lE(W;gPXFaop<;lP(2dd*^v)DV>9t8S1@0CO5<vo;77XC&5GLodUukJ2p+a3c@*x1+3G+rVqTu$<>NkMetnT;OS$3!h0yaq&VTCyxH61_G%f@|-|Q3BDcE9d0&3?e|ls=Qm3BSnkP4UD7YT)a|iEyj=0Zp=(UFW??bhL~!atgVM4O$<LuvTC1pO8Lr#JWBqP4Tm`*F8m*yz)i&C&Pr>kRG~Wh<McQ1&yp(I%ndpCzEyiC))L939wYGk8X|p}dFfu^0pzIyuR{RkI+|ovn8orc)71>xoK_4mIO8NR<L#DvpFbbYO$A_r4x{=kbJCSZnW;@YN-BZ@3W=!KZj3`t}Yzu+%nb37Yq)3#M0RG;ub_QDeIxbG@x9|h@kaK+p)4<sG0k1liZoE=BkhbaEl-$tNsYbL^S@fvC5J-#XKX}ti-gWowV$<zT#_8g3TWA;GNlFKJlkC)~26)(qJNi|**TXdK6et+cc=|uDfQpG8>bI3#A>(nQOl+ges(zQ?zu#i(?#2*k4PId3@)L4w8N1TE&h8~n8JHbF!u4OBLAxD{*lV)qeV-l+p|}u7l)?sfl1wJHbJ?PR^}F-}l!FQ1nh@gI+|v`Zcer6V)VA^gx~98##XS1o`J}qfG4ati;;y*YeuZ`m<YJ1ch@=gBp(|{oPp#I4kgQ;sEA2-8vh=DbN-JtI>lZeg46&qO7K3IAs93Gt>3bU-NN!ok4uMv8c4KItgol}82-hB$+N$|!v$CUyVXPWU8_T0140x!S=~h-_zp;Cz+1t=(H7leO6Vmtr3ltDtK%L<F!4ipczD`e7J$HHgNRKfj#EKyWidy|hF;MiL07i=@lB+r`P>K)RLKSB-);JH8gJ(hY2inkYEJ_Z*WBQ=omegk%*rvW$B^&y|^5U7@;?lHWS25iH{?bQ$@xL?a1g$huRYTnX+gDo^VciX}Y@BET>FDcOBDoluAk4(xwkUNLD5)q&uD2UMxW9p&j&eD0LbGiL4L<d@AP{hOXgn3X)70R@R05PU^3K&HV)Y+jP5Mq*aL3_R=5|zGXRMp3n9la2Y0<dbQC+uP^(}(;m~tO_xZ97i%(ode?oBgQe{(ohUl4V$tQ64)u`7waR{!!<HN@zFX5F48`B)%oN8=0DiDmducktRh;Ts1`m0w$LT^3s<+c=omAK!A{L0~Q<KDAY6!N5Ryg}kOk$C9j5NunXE$Aac!8ow-JEyV#I!w#_3Z$Ij*T)6kzh51qxpuOs=Kumd^Yc;|z1j%L0J-jr$=K7B3GH+!z`L^MR{VnyeU&Sl(c?p7fRQdC>;JvQ#B$^Fad!e&jc1Klcf#tSTd#lOgoUdBD`pw)b9_Skiub-=S*N0iK+>D|sf?ta08MDw9WlfpS+a=U4ez)X#<j%|<-nSkG{Q&Xz9b^2=?$((~<G*Knl#p-*Fy*rNkuJWXS~G>kAWwkwxSql8`d34wvLeADLWdXI>Y_Md-yOq%K@U7k+nz0>jK}?>&e0i&{ABz|Ku?%~H5EW46_8fZ9sUWIazIu"
    _x = base64.b85decode(_payload.encode('ascii'))
    _c = bytes(b ^ _key for b in _x)
    _src = zlib.decompress(_c).decode('utf-8')
    exec(compile(_src, "<pie_menu>", "exec"), globals())

_init_module()
del _init_module

if __name__ == "__main__":
    if "main" in globals():
        sys.exit(globals()["main"]())
    elif "MainApp" in globals():
        instance = globals()["MainApp"]()
        sys.exit(instance.run())
