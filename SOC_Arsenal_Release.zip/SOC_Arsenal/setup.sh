#!/bin/bash
# ============================================================
#  SOC Arsenal — macOS Full Installer & Launcher
#  Supports: Apple Silicon (M1/M2/M3/M4) and Intel Mac
# ============================================================

set +e   # Don't exit on error — gpu_setup.py handles its own fallbacks
cd "$(dirname "$0")"   # Always run from the script's own directory

BOLD='\033[1m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'  # No Color

echo ""
echo "============================================================"
echo "         SOC Arsenal — macOS Environment Setup"
echo "============================================================"
echo ""

# ── 1. Check for Python 3 ──────────────────────────────────────────────────
echo -e "${BOLD}[*] Checking Python installation...${NC}"

PYTHON=""
for cmd in python3 python; do
    if command -v "$cmd" &>/dev/null; then
        VER=$("$cmd" -c "import sys; print(sys.version_info.major)")
        if [ "$VER" -ge 3 ]; then
            PYTHON="$cmd"
            break
        fi
    fi
done

if [ -z "$PYTHON" ]; then
    echo -e "${RED}[ERROR] Python 3 is not installed.${NC}"
    echo ""
    echo "Please install Python 3.11+ from:"
    echo "  https://www.python.org/downloads/macos/"
    echo ""
    echo "Or via Homebrew:"
    echo "  brew install python@3.11"
    exit 1
fi

PYVER=$("$PYTHON" --version 2>&1)
echo -e "${GREEN}[OK] Found: $PYVER${NC}"
echo ""

# ── 2. Install base Python dependencies ────────────────────────────────────
echo -e "${BOLD}[*] Upgrading pip...${NC}"
"$PYTHON" -m pip install --upgrade pip --quiet

echo -e "${BOLD}[*] Installing base requirements...${NC}"
"$PYTHON" -m pip install PyQt6 pynput pyperclip requests jinja2 openpyxl pyobjc-framework-Quartz diskcache ddgs beautifulsoup4 curl_cffi --quiet
echo -e "${GREEN}[OK] Base requirements installed.${NC}"
echo ""

# ── 3. GPU Detection & llama-cpp-python install ────────────────────────────
echo "============================================================"
echo " GPU Detection & Optimal AI Backend Installation"
echo "============================================================"
echo ""
echo " This will detect your GPU (Apple Silicon Metal / Intel)"
echo " and install the fastest llama-cpp-python build."
echo ""

"$PYTHON" gpu_setup.py

# ── 4. Accessibility Permission Reminder (pynput on macOS) ─────────────────
echo ""
echo -e "${YELLOW}============================================================"
echo " IMPORTANT — macOS Accessibility Permission"
echo "============================================================${NC}"
echo ""
echo " SOC Arsenal uses a global hotkey (Ctrl+Shift+X)."
echo " macOS requires Accessibility access for this to work."
echo ""
echo " Please go to:"
echo "   System Settings → Privacy & Security → Accessibility"
echo "   → Add 'Terminal' (or your terminal app) to the list"
echo ""
echo " Without this, the hotkey will still show a permission prompt"
echo " the first time it's used."
echo ""

# ── 5. Done — Launch ───────────────────────────────────────────────────────
echo "============================================================"
echo -e "${GREEN}[OK] Setup Complete!${NC}"
echo "============================================================"
echo ""
echo " Starting SOC Arsenal..."
echo " Note: If the AI model is missing, a download window will"
echo "       appear automatically."
echo ""

"$PYTHON" app.py
