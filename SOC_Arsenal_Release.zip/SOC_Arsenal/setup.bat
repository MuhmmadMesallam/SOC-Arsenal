@echo off
title SOC Arsenal Full Installer
color 0A

echo =======================================================
echo          SOC Arsenal - Full Environment Setup
echo =======================================================
echo.

:: 1. Check for Python
python --version >nul 2>&1
if %ERRORLEVEL% equ 0 (
    echo [OK] Python is already installed.
    goto :INSTALL_DEPS
)

echo [!] Python is not installed or not in PATH.
echo [*] Downloading Python 3.11.8 Installer...
powershell -Command "Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.11.8/python-3.11.8-amd64.exe' -OutFile 'python_installer.exe'"

echo [*] Installing Python 3.11.8 (Silently for current user)...
:: InstallAllUsers=0 ensures we don't need Admin rights. PrependPath=1 adds to PATH.
start /wait python_installer.exe /quiet InstallAllUsers=0 PrependPath=1 Include_test=0
del python_installer.exe

:: Refresh PATH locally for this script so we can use python immediately
set "PATH=%LocalAppData%\Programs\Python\Python311\Scripts;%LocalAppData%\Programs\Python\Python311;%PATH%"

python --version >nul 2>&1
if %ERRORLEVEL% neq 0 (
    color 0C
    echo [ERROR] Python installation failed or path not updated. 
    echo Please restart your computer or install Python manually from python.org.
    pause
    exit /b 1
)

:INSTALL_DEPS
echo.
echo [*] Updating PIP...
python -m pip install --upgrade pip --quiet

echo [*] Installing base requirements...
python -m pip install -r requirements.txt --quiet

echo.
echo =======================================================
echo [*] GPU Detection ^& Optimal AI Backend Installation
echo =======================================================
echo.
echo This will detect your GPU and install the fastest
echo llama-cpp-python build for your hardware.
echo.

if exist "%~dp0gpu_setup.py" (
    python "%~dp0gpu_setup.py"
) else (
    python -c "import gpu_setup; getattr(gpu_setup, 'install_llama_cpp', lambda: None)()"
)

echo.
echo =======================================================
echo [OK] Setup Complete!
echo =======================================================
echo.
echo Starting SOC Arsenal...
echo Note: If the AI model is missing, a download window will appear automatically.
echo.

set "TARGET_SCRIPT=%~dp0app.py"
if not exist "%TARGET_SCRIPT%" (
    if exist "%~dp0run_protected.py" (
        set "TARGET_SCRIPT=%~dp0run_protected.py"
    )
)

python "%TARGET_SCRIPT%"
pause
