@echo off
title SOC Arsenal Full Installer
color 0A

echo =======================================================
echo          SOC Arsenal - Full Environment Setup
echo =======================================================
echo.

:: 1. Check for Python
python --version >nul 2>&1
if %ERRORLEVEL% equ 0 (
    echo [OK] Python is already installed.
    goto :INSTALL_DEPS
)

echo [!] Python is not installed or not in PATH.
echo [*] Downloading Python 3.11.8 Installer...
powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.11.8/python-3.11.8-amd64.exe' -OutFile 'python_installer.exe'"

echo [*] Installing Python 3.11.8 (Silently for current user)...
start /wait python_installer.exe /quiet InstallAllUsers=0 PrependPath=1 Include_test=0
del python_installer.exe 2>nul

:: Refresh PATH locally for this script so we can use python immediately
set "PATH=%LocalAppData%\Programs\Python\Python311\Scripts;%LocalAppData%\Programs\Python\Python311;%PATH%"

python --version >nul 2>&1
if %ERRORLEVEL% neq 0 (
    color 0C
    echo [ERROR] Python installation failed or path not updated. 
    echo Please restart your computer or install Python manually from python.org.
    pause
    exit /b 1
)

:INSTALL_DEPS
echo.
echo [*] Updating PIP...
python -m pip install --upgrade pip --trusted-host pypi.org --trusted-host files.pythonhosted.org --quiet

echo [*] Installing base requirements...
python -m pip install PyQt6 keyboard pyperclip requests jinja2 openpyxl diskcache ddgs beautifulsoup4 curl_cffi --trusted-host pypi.org --trusted-host files.pythonhosted.org --quiet

echo.
echo =======================================================
echo [*] GPU Detection ^& Optimal AI Backend Installation
echo =======================================================
echo.
echo This will detect your GPU and install the fastest
echo llama-cpp-python build for your hardware.
echo.

python gpu_setup.py

echo.
echo =======================================================
echo [OK] Setup Complete!
echo =======================================================
echo.
echo Starting SOC Arsenal...
echo Note: If the AI model is missing, a download window will appear automatically.
echo.

python app.py
pause
