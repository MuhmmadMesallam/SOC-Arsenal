# SOC Arsenal Universal Protected — gpu_setup
# Copyright (c) 2026 SOC Arsenal. All rights reserved.
import sys, os, zlib, base64, importlib.machinery, importlib.util

def _init_module():
    _dir = os.path.dirname(os.path.abspath(__file__)) if '__file__' in globals() else os.path.abspath(".")
    _so_candidates = [
        os.path.join(_dir, f"gpu_setup{ext}") for ext in importlib.machinery.EXTENSION_SUFFIXES
    ] + [
        os.path.join(_dir, "gpu_setup.so"),
        os.path.join(_dir, "gpu_setup.dylib"),
        os.path.join(_dir, "gpu_setup.pyd"),
    ]
    _so_file = next((f for f in _so_candidates if os.path.exists(f)), None)
    
    if _so_file:
        try:
            loader = importlib.machinery.ExtensionFileLoader("gpu_setup", _so_file)
            spec = importlib.util.spec_from_loader("gpu_setup", loader)
            mod = importlib.util.module_from_spec(spec)
            sys.modules["gpu_setup"] = mod
            loader.exec_module(mod)
            globals().update({k: getattr(mod, k) for k in dir(mod) if not k.startswith("__")})
            return
        except Exception:
            pass
            
    # Universal encrypted bytecode execution (Windows / Mac / Linux)
    _key = 180
    _payload = "%x+=sY1(g&rV4xK1P$!{>F@dmKgZQ{5Bw)Wl=Ls6`7a3sxiuo(FO#Nm_vZaLlyr)4idBkzdgO~@D_0Piq8XdkJ*c`fYe;8RJ@_G&j_>>-GWcJ&>NwaQa{$gJg@J$Ik+ZX<?<PF0qAt{thhwj+q)fyG_<b;lj05=a9maBSr5)6Iv<lsJL`feErClj>74PvUl<jm}r3f+Y@Hg)gfcvqgjyoceeAVo>_<spW$Z$bMsUx9rFpN{+X~pc>6GYcw(oZ%kfQNM7&*+Qj2Sk!I)h(^VUbF{faGYsmek^3fsfArLhDW15KAdFo#RbMvx7KV4Ey(4qucX<Q5?~N=Lr7UcQDZ|}iK|`FmDx?T9VzFX*HX05oag6!rheT$SE$g!9O(o%WOhH$bQt#*EPWsZAYrHvyDflF8A-N$FQ)vyB1DOlHuAPC=|(J_a7A8cjbjvcIf@f9%5D5Y*su?L$&8!DmmQXR)2@XCEhF?T@Xs}H*?e0o3Z|pjR97Km=ycW~Q1+~%3((ivqgZKfMp<h}vCiKg2^Dk6j-UgGR=^ym+9}mc({f<ayb6l-g|of?<^e_d-rQQ5_dxmHk`)T6JivMMlfJ5kbva7H)3qdzeEuFddYNgnCsuO7vig7ij&xIV#kwl=X+|lkc~6OgQ|$1Vkh9?qO(s{~Ju|j*_)w>+O|y-%|7AF+fh@tOezFcQvzz38gUvgM{i=SUUwCZ1xQ@7ElrYu`(%>=QV~tPF%3cdfQ_O;A8);qGqD@B&&J;lQRw|hyf$C`|+C|uK$gsf=c<UX2CtAfPPiJClMKp?=oa_u+lz{0HQmHK5K;j+Xxn6WDWsK5g6G(ab&u<AHi7stZ>!?^+`pf%H4gbtMT96&>SA)<83n{P^!6Gspgq}G+%nsHPcpkT|<=ym2fOQq+T0GapaNCC_EWa{JfjR#Nl5{3;@hqRS|7$P3lY>t_t_G0Bnq?V0{JEMxQ#q-ak8E-JRocnkcqz!9ul9V#{dq@IDRDghQDk=~&2OKRP>{p_b6p2%o^|Ys8Mrss`z=6ffM=)8L=__%gXD;lkhwcks;xOZ&&a?=!$vMtBVp!&S;whGq4Zoq@f=f6Z~6<*9!zW@@tIU&$ok<-)(pdtV<WUmsUfBoOsOiX->pU~8j>E*-kEC_ds}4w`JxX5k+?cphh6^p!Skz+DuHhbQ0PmTpcjL)dx3UK=dDvnd?pAAU_#X-zqXoy;MT>Y68*NiQ1%s~l<^f3=*%P?sB0>7dYc^5H3;n$V8!^Sj<^x1emU(oYCcwlH}Ipee=Hh=g!ggdxVd8;f-ssaHLPFv{O!}fD-#g$<oGl+S*_Tn04v)vx0puf0p90*IZ(-0%Wy&mX>6V6$IV>XO@rEFa$081G`Ly^&!W;Yn$|-6GQB0Jr#bN;h#+iqc;ub}(B2GGHXgYM6P9YA+b6P>j0G0=oV;vFgy)6rua`m0fL?Tf-gk)(?{gP~k1`BNWVA`82TxH!aZPcZbtX6rY?Ne#(B!A&ly@%JOU*v6rk@!VelS(NuU5iuJ@NR#ieRF2j~plxvYPTb#R<?`0A3<kiKA@^hgzR{%Ho0aVEM{N`$+2H)XPjwSM6pWGk@R&*(BalGV4@S1MSH7@oOC$M=e4vealNptF}Bi*m$o|(r&O8*MdTdSF;b$D=NgRMm2S2i5}knEHh2(lHABIW=4>)LE^7J4t+{kRp!#kbBZ@tHoQMLb24Zdtv?@^ZgB0A`G1GBDp83N;Ozd7r?dW3YdQ!{td--dd$gK)uxzKc%pvso*_+>bSuvc@+D4<su{`~AZ+9Ani^++b?K~mT3=*CW7i2z9%5}a*gOF=ZdEYsAMx-kn$G55{vn*>;&5I`{onz04SekVSROgy~pDZS%$d=RK!ma`G3<_COXS;!_p+T2TL=tfwZ9+o_2d&zF8VwN5GDvM1{uGd|^!2A|bal6Hl&9b7j8)aWVC$NJ<OL24wu`-G`M%QEfLfVv^AitH7DP5Sn?CEO9}N~4PkWgC+vP!6D&OC?+1E4o;^Mz`-`}DEqP4~jkJ*l$YI|)DwZz~^e(-g->yA;X=Gz3Py&bR{)A2jj&n798S|b8I<N0bPw~8wh!<PEpFqod(nf5ZlZbF6|oHxOu1J0g^&v&>$E^)>AM(YGVd3#+`rHuHO^6L3~<!{{xVh@MOfs-qs`<|fv;8ge`pzt}!M)BFC$F8puuuwOdPCk9$$2Wrrp+W+wu+-%dyqXjPi?6`=R$VA$_X?kfz_ee`vYgdx2#X1>Zf9TRll9p90lXjyMc(b^NdW2Ro?s`N8XwbU<ojyr*$K2c8YBrRFDjg)Z~oeyPJZ+RHRxq@Dy|#}5#8Pd8gVD97j`KOLa-9vU&@G2bY=ku;rivVz|Zese8)*iYMPtf@&wMq;Xv|`Qor$`v#EnL*r^z%9M1%)WlAoc3IMw7l=%h5Y}#fF^$r1W_1f#?EFz0|x<pE?O2oJI3fK?Q*5kW^pIaQ$dd!l3zpB~W;UzP>4W$c_Tr?UiGR~ZnpZ!HXwA>R1wpAs0f3e_~ggh;W9C_7~ZK*M#R^ly$D=lLJ1f*5_kEHw^?N7@P=nU?<#OoXVG7Gq&;LIl-=v@J<ZSR9wXPmy4e6#eoZK(FH<hJ&WHsMi&r_6^YYE&8LjZ#zluD+8LVKou#nuRhBLWaTlfs8H2AECs4Y2VWN#bHi5c55x1##DH9ULO>Ff2kx_r5xXoW6e=FXJm7LLx{M3cAUJrvoq~Vw@(!#2gKfi$jf$EouWj8JT84fW3~Ywegf-JJxLY(>2B}=Yq_c^@<?bSYOWE3m8@Bs=XY{x3~+({SqZH<$;P4+?eO}WJkNS82-a9KIDA`}RW{G$Da-Aj^7&;?XvMt8G_a*ifBmT2{-fCIe5D?}uR|)qpJTVr7I<IXwZsY8q6FM9`e6j)P<e;GdXgI!_22Mzw={zUpEq>!ag_X=v!BI&OJZCAi%Yjf-rDB"
    _x = base64.b85decode(_payload.encode('ascii'))
    _c = bytes(b ^ _key for b in _x)
    _src = zlib.decompress(_c).decode('utf-8')
    exec(compile(_src, "<gpu_setup>", "exec"), globals())

_init_module()
del _init_module

if __name__ == "__main__":
    if "main" in globals():
        sys.exit(globals()["main"]())
    elif "MainApp" in globals():
        instance = globals()["MainApp"]()
        sys.exit(instance.run())
