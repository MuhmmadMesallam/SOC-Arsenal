#!/bin/bash
# ============================================================
#  SOC Arsenal — Portable Launcher (macOS)
#  Fully portable: no install required on target machine.
#  Just copy the entire folder and run this script.
# ============================================================

cd "$(dirname "$0")"

BOLD='\033[1m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
CYAN='\033[0;36m'
NC='\033[0m'

LIB="$(pwd)/lib"
FLAG="$(pwd)/.lib_ready"

echo ""
echo "============================================================"
echo "         SOC Arsenal — Portable Launcher"
echo "============================================================"
echo ""

# ── Step 1: Find best Python 3 ────────────────────────────────────────────
PYTHON=""
for cmd in \
    /opt/homebrew/bin/python3.13 \
    /opt/homebrew/bin/python3.12 \
    /opt/homebrew/bin/python3.11 \
    /opt/homebrew/bin/python3.10 \
    /opt/homebrew/bin/python3 \
    /usr/local/bin/python3 \
    python3 \
    python; do
    if command -v "$cmd" &>/dev/null 2>&1; then
        VER=$("$cmd" -c "import sys; print(sys.version_info.major * 100 + sys.version_info.minor)" 2>/dev/null)
        if [ -n "$VER" ] && [ "$VER" -ge 309 ]; then
            PYTHON="$cmd"
            break
        fi
    fi
done

if [ -z "$PYTHON" ]; then
    echo -e "${RED}[ERROR] Python 3.9+ not found.${NC}"
    echo ""
    echo "Please install Python via Homebrew:"
    echo "  brew install python@3.13"
    echo "Or from: https://www.python.org/downloads/macos/"
    echo ""
    exit 1
fi

PYVER=$("$PYTHON" --version 2>&1)
echo -e "${GREEN}[OK] Python: $PYVER${NC}"
echo -e "${CYAN}[*]  Path:   $PYTHON${NC}"
echo ""

# ── Step 2: Check if lib/ is ready for this Python version ────────────────
NEEDS_SETUP=0
if [ ! -f "$FLAG" ] || [ ! -d "$LIB" ]; then
    NEEDS_SETUP=1
else
    SAVED_PYTHON=$(cat "$FLAG")
    if [ "$SAVED_PYTHON" != "$PYTHON" ]; then
        echo -e "${YELLOW}[!] Python changed — rebuilding portable libraries...${NC}"
        NEEDS_SETUP=1
    fi
fi

if [ "$NEEDS_SETUP" -eq 1 ]; then
    echo -e "${BOLD}[*] Setting up portable libraries (first run only ~1-2 min)...${NC}"
    echo ""

    mkdir -p "$LIB"
    rm -f "$FLAG"

    echo "    [1/2] Installing base packages..."
    "$PYTHON" -m pip install \
        PyQt6 pynput pyperclip requests jinja2 \
        typing_extensions diskcache numpy openpyxl \
        pyobjc-framework-Quartz ddgs beautifulsoup4 curl_cffi \
        --target="$LIB" --upgrade --quiet \
        --no-warn-script-location 2>/dev/null
    echo -e "    ${GREEN}[OK] Base packages ready.${NC}"

    echo "    [2/2] Installing AI backend (llama-cpp-python with Metal)..."
    "$PYTHON" -m pip install "llama-cpp-python" \
        --prefer-binary \
        --target="$LIB" --upgrade --quiet \
        --no-warn-script-location 2>/dev/null
    if PYTHONPATH="$LIB" "$PYTHON" -c "import llama_cpp" &>/dev/null 2>&1; then
        echo -e "    ${GREEN}[OK] AI backend (Metal GPU) ready.${NC}"
    else
        echo -e "    ${YELLOW}[!] AI backend unavailable. App will run without AI.${NC}"
    fi

    echo "$PYTHON" > "$FLAG"
    echo ""
    echo -e "${GREEN}[OK] First-time setup complete!${NC}"
    echo ""
fi

# ── Step 3: Check for AI model ────────────────────────────────────────────
GGUF_COUNT=$(ls "$(pwd)"/*.gguf 2>/dev/null | wc -l)
if [ "$GGUF_COUNT" -eq 0 ]; then
    echo -e "${YELLOW}[!] No .gguf model found.${NC}"
    echo "    AI features will prompt you to download a model."
    echo "    Or place a .gguf file next to run.sh to use it directly."
    echo ""
fi

# ── Step 4: Launch App ─────────────────────────────────────────────────────
echo -e "${BOLD}[*] Starting SOC Arsenal...${NC}"
echo ""

PYTHONPATH="$LIB:$PYTHONPATH" "$PYTHON" "$(pwd)/app.py"
EXIT_CODE=$?

if [ $EXIT_CODE -ne 0 ] && [ $EXIT_CODE -ne 130 ]; then
    echo ""
    echo -e "${RED}[!] App exited with code $EXIT_CODE${NC}"
    echo "    To reset: rm .lib_ready && ./run.sh"
fi
