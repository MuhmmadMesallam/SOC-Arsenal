# SOC Arsenal Universal Protected — clipboard_manager
# Copyright (c) 2026 SOC Arsenal. All rights reserved.
import sys, os, zlib, base64, importlib.machinery, importlib.util

def _init_module():
    _dir = os.path.dirname(os.path.abspath(__file__)) if '__file__' in globals() else os.path.abspath(".")
    _so_candidates = [
        os.path.join(_dir, f"clipboard_manager{ext}") for ext in importlib.machinery.EXTENSION_SUFFIXES
    ] + [
        os.path.join(_dir, "clipboard_manager.so"),
        os.path.join(_dir, "clipboard_manager.dylib"),
        os.path.join(_dir, "clipboard_manager.pyd"),
    ]
    _so_file = next((f for f in _so_candidates if os.path.exists(f)), None)
    
    if _so_file:
        try:
            loader = importlib.machinery.ExtensionFileLoader("clipboard_manager", _so_file)
            spec = importlib.util.spec_from_loader("clipboard_manager", loader)
            mod = importlib.util.module_from_spec(spec)
            sys.modules["clipboard_manager"] = mod
            loader.exec_module(mod)
            globals().update({k: getattr(mod, k) for k in dir(mod) if not k.startswith("__")})
            return
        except Exception:
            pass
            
    # Universal encrypted bytecode execution (Windows / Mac / Linux)
    _key = 70
    _payload = "KAam1jZDRMR{EiBu+XBENw%ml4lDp4_K)-^2XDKvyv9t3BOoSNy436d^i1;E9@>pwF2XbYJ&@x6b!t!~r7p#<Jj`26JuUx?Ne}gBf@Q|z!Cv!0H*3-$gp*UFBqz4(ER!p5BWPv230=IVt);t+y;*0{af|"
    _x = base64.b85decode(_payload.encode('ascii'))
    _c = bytes(b ^ _key for b in _x)
    _src = zlib.decompress(_c).decode('utf-8')
    exec(compile(_src, "<clipboard_manager>", "exec"), globals())

_init_module()
del _init_module

if __name__ == "__main__":
    if "main" in globals():
        sys.exit(globals()["main"]())
    elif "MainApp" in globals():
        instance = globals()["MainApp"]()
        sys.exit(instance.run())
