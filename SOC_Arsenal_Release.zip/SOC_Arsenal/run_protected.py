# Auto-generated binary launcher for compiled SOC Arsenal
import sys
import app

if __name__ == "__main__":
    if hasattr(app, "main"):
        sys.exit(app.main())
    else:
        app_instance = app.MainApp()
        sys.exit(app_instance.run())
