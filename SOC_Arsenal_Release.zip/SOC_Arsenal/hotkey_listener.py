# SOC Arsenal Universal Protected — hotkey_listener
# Copyright (c) 2026 SOC Arsenal. All rights reserved.
import sys, os, zlib, base64, importlib.machinery, importlib.util

def _init_module():
    _dir = os.path.dirname(os.path.abspath(__file__)) if '__file__' in globals() else os.path.abspath(".")
    _so_candidates = [
        os.path.join(_dir, f"hotkey_listener{ext}") for ext in importlib.machinery.EXTENSION_SUFFIXES
    ] + [
        os.path.join(_dir, "hotkey_listener.so"),
        os.path.join(_dir, "hotkey_listener.dylib"),
        os.path.join(_dir, "hotkey_listener.pyd"),
    ]
    _so_file = next((f for f in _so_candidates if os.path.exists(f)), None)
    
    if _so_file:
        try:
            loader = importlib.machinery.ExtensionFileLoader("hotkey_listener", _so_file)
            spec = importlib.util.spec_from_loader("hotkey_listener", loader)
            mod = importlib.util.module_from_spec(spec)
            sys.modules["hotkey_listener"] = mod
            loader.exec_module(mod)
            globals().update({k: getattr(mod, k) for k in dir(mod) if not k.startswith("__")})
            return
        except Exception:
            pass
            
    # Universal encrypted bytecode execution (Windows / Mac / Linux)
    _key = 227
    _payload = "n>kjyj*K|f^BoPmq8Dh&H#Rwe=rx1=vq!49*NAn-Ahq{qBdeD$xs1jN#f`Fq+<{z^T!)m$#&B^TF_#eZXg3m@6cY_vK&P^_vG7*0z=Hfp6$)NSDFs?BdVRK0`!0vJbG)<!8N=N)q;>}<s(*aGUIa>gbD0*RylV(?20#Y^E+z&N%!fHmY=Xot==pAKExmkSpM8H{-`-^uc4>%31QHmjcUSs{p><CK4tu`JA4ICr@Y<|#%XxDWUoq%isWC}^Y6$y|{iHyIB*d(o++MG}f4*JWo!}WHq`3tY%msl(3>@11ZqePqnkG@lyRE<x1B5|W-~aL(YPyK@T=uER3HtuJ`X7o~x$F~^z!!hF*32H}gGm3Z>&!68@CFu_UpG+X+-<-i_j+as5_HloBa@fQrKk$e2`Vr2!(w3))-*Sw;+StFvhTfXc@;Ecun?x4*dMA*bWvwC4!E6o5xH=H5X4E*zqHUsr9C0@mgrG|{F>y4*x9Fl{%hi6EfOql*kmW&*ZrRQ4q+OFtb6WNI#El?4cfv`>hgvqsNSBBk_cIB*&Df}&ZbHVj~^8Q4{P6cX`nA$z{Kxi(7;*IUDyC>79Mk-1-!%E?$_2}#%g(>6-TIkBlE#e{(<+I^Qx7A#^ZTZmSE<mCGK?dRdcvU<p^qA-L;m@!_5s~6q64QNtC64;u|mLbW5_L8@qJYaPz3@dEdrNNO9Crsv?Py&&r4K|7jlNS0d2PNQ0?@eFA5mWBPS?(j6j8(TkbzigJ1u6NK0G=Exp;VTc9pHc<sJ_&jS-`Z^1X0*ivUeEGp*On<C`t5-uO&nQdqnz&rJ1oABQ>@??dHl3j}wLT|sktBQrQ%iO8;Fd=5CWU{c&JtHQ>OU55ssI9oA<|EuUFW3S)}Nmj9~;1D5poBw5US9hEf$J)(Px~Y^^Fl0(JbJWA3)`_;qLc<!iR8QsWh>Df$1oqD&_63^t<*vrF)7Mn)ar=sML7Eo4GVhXN|*~o`SFFc0+^>rjIj>E^U<vSgXbahQmZJx6uRvnT?jXLR*7DS8Q`c&}wGyySkqNQg%LTvrf2Up$6<D8CU@}j}r$20%so+9-yR?qSNG79vZP%MjngGw#GDHw8Dg2I{T&lmoDAY_&l+b;QY1sZ~aEv`=`D8-QQ-BDX2ruG}T)plxE?J2^o2)gEC4qt;5^p^)rU)=EbtXsX}mP$$j9SI2N$*NQhkTzT+EC6FI-X^~4IXscYo4M1!yt<ImAI$CtG<NKxe>E`F%pj7??*-z?J_pj9UPR^f4+tKV5uaQ%wI_h9CLBjD`AzdcXWQG#dy{yK9(R{b_M(89)Csu@;4612LCtmAU;gn7A_+jHf@m#MT?;PeR^4NwRSQoS;arDXybyex&FgC~kDdJh>ygZTbiT-|Xk$dFkg!W*Us?2C>`_}1;>RMoq#)U{!aNS0k+ZWuE`14|8ovurdjsVJahF}5a$WsbX1TM23+zhBP;wpOdVeUuxY*t8WJaRh<Ye>|8w*jp{<5mfqCaF8`$`~8Xp$C;%J;u8VsxTzq$9z%^8GrN&n3Pyh!e!2@0HJ~AMGn?8@Hw_B$P08?ei4rnb(4z`g2dS>i262qdYkp-uh&c?7i8)N;QDqz?d}Mzf(Zx6BjEDIdn6m7fbof}4)b=zf?R{d{1ue1<!R;WwZBRKa@T!Td+4$ypIlcC}P-ocRzNchhG^s^<HF3>TW_-|Ul+7cN@&IG&hRNe)3KI_Sc&f<Q8~N2MLUyUZ$84mf5Wo>I_sOVba1$3BgS%3+05MuejUt{A2g5m)?yY!3JqE~~K#QIxB8|L0^|hY>-K~j!IvsMO*?aFpn}Hs_<(i7in-hKTcSfzvzD<dp&xXciHWnKy|3)bEZ(O}xFeTj==jf1z?#|gimmj5jO_0Hz<|kmZE$Wrp1=}HX@R-1^6RnB4A--Wz@^96oaSV9kEIpZIpena=qF632n`qtz9=&zADp-1r3<SK0*uObcJK&5IQTPT2eUUVjknCK|pH7goTUBPNat`#Z!;~b8VIkV9+U`Omp-Kk!1$SJVApK>*n}wVB(NZ7)po$EYPzED&xl4cvy^a-1xK0Xnz@vE=RYBV&DOl1lWH5`%qZkBP4#VYd{XxGfLN&=9PDgm^cA;(@tZJ07fC~aMJz01G(vJPbeULB~fLEAg+kjtVt%#{p_V^Ak<)C1vnBF+3FdgsPkN8zBq_s5Af?I3x*9ALX9uPD<t_0=dP{@DaDCu>5zMquIDF%)|s?J2%rxjF&n(IubK1-EYZVWMmZ4?U7N`!$ooxl|#O>QZzpsI|-C%@d}+{I<oDh*V2d-S2W<{aU)ba4a"
    _x = base64.b85decode(_payload.encode('ascii'))
    _c = bytes(b ^ _key for b in _x)
    _src = zlib.decompress(_c).decode('utf-8')
    exec(compile(_src, "<hotkey_listener>", "exec"), globals())

_init_module()
del _init_module

if __name__ == "__main__":
    if "main" in globals():
        sys.exit(globals()["main"]())
    elif "MainApp" in globals():
        instance = globals()["MainApp"]()
        sys.exit(instance.run())
