@echo off
title SOC Arsenal
cd /d "%~dp0"

set PYTHON=
for %%P in (python py python3) do (
    if not defined PYTHON (
        where %%P >nul 2>&1 && set PYTHON=%%P
    )
)

if not defined PYTHON (
    echo [!] Python not found. Launching setup...
    if exist setup.bat (
        call setup.bat
        exit /b
    ) else (
        echo [ERROR] Python not found and setup.bat is missing!
        echo Please install Python from https://www.python.org/downloads/
        pause
        exit /b 1
    )
)

:: Quick check if dependencies are installed
%PYTHON% -c "import PyQt6, keyboard, pyperclip, requests, jinja2, openpyxl, diskcache, llama_cpp" >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo [!] Missing dependencies detected. Launching setup.bat...
    if exist setup.bat (
        call setup.bat
        exit /b
    ) else (
        echo [*] Installing requirements...
        %PYTHON% -m pip install --quiet PyQt6 keyboard pyperclip requests jinja2 openpyxl diskcache
        %PYTHON% gpu_setup.py
    )
)

:: Launch application
start "" /b %PYTHON% app.py
