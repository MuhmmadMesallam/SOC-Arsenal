@echo off
title SOC Arsenal
cd /d "%~dp0"

REM === Find Python Executable ===
set PYTHON=
for %%P in (python py python3) do (
    if not defined PYTHON (
        where %%P >nul 2>&1 && set PYTHON=%%P
    )
)

if not defined PYTHON (
    echo [!] Python not found. Launching setup...
    if exist setup.bat (
        call setup.bat
        exit /b
    ) else (
        echo [ERROR] Python not found and setup.bat is missing!
        echo Please install Python from https://www.python.org/downloads/
        pause
        exit /b 1
    )
)

REM === Quick Dependency Check ===
%PYTHON% -c "import PyQt6, keyboard, pyperclip, requests, jinja2, openpyxl, diskcache, llama_cpp" >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo [!] Missing dependencies detected. Launching setup.bat...
    if exist setup.bat (
        call setup.bat
        exit /b
    ) else (
        echo [*] Installing requirements...
        %PYTHON% -m pip install --quiet "numpy<2" PyQt6 keyboard pyperclip requests jinja2 openpyxl diskcache
        %PYTHON% gpu_setup.py
    )
)

REM === Resolve pythonw.exe for GUI Taskbar ===
for /f "delims=" %%I in ('where %PYTHON%') do (
    if not defined PYEXE set "PYEXE=%%I"
)
for %%I in ("%PYEXE%") do set "PYDIR=%%~dpI"
set "PYTHONW=%PYDIR%pythonw.exe"

set "TARGET_SCRIPT=%~dp0app.py"
if not exist "%TARGET_SCRIPT%" (
    if exist "%~dp0run_protected.py" (
        set "TARGET_SCRIPT=%~dp0run_protected.py"
    )
)

if exist "%PYTHONW%" (
    start "" "%PYTHONW%" "%TARGET_SCRIPT%"
) else (
    start "" "%PYEXE%" "%TARGET_SCRIPT%"
)
