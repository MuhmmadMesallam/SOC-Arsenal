@echo off
title SOC Arsenal - DEBUG MODE
cd /d "%~dp0"
echo ============================================
echo  SOC Arsenal - Debug Launcher
echo ============================================

for %%P in (python py python3) do (
    where %%P >nul 2>&1 && (
        echo [OK] Found Python: %%P
        %%P app.py
        if %errorlevel% neq 0 (
            echo.
            echo [ERROR] App crashed with error code %errorlevel%
        )
        pause
        exit /b
    )
)

echo [ERROR] Python not found in PATH!
pause
