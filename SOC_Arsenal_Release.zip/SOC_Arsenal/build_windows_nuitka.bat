@echo off
REM ============================================================
REM  SOC Arsenal — Windows Nuitka Build Script (Optional)
REM  Compiles Python sources into Windows .pyd extension binaries
REM ============================================================
title SOC Arsenal - Windows Nuitka Compiler
cd /d "%~dp0"

echo [1/3] Checking Python & Nuitka...
python -m pip install --upgrade nuitka

echo [2/3] Compiling modules to Windows .pyd binaries...
python -m nuitka --module docx_exporter.py
python -m nuitka --module ai_handler.py
python -m nuitka --module vt_handler.py
python -m nuitka --module hotkey_listener.py
python -m nuitka --module pie_menu.py
python -m nuitka --module clipboard_manager.py
python -m nuitka --module gpu_setup.py
python -m nuitka --module app.py

echo [3/3] Windows compilation complete!
pause
