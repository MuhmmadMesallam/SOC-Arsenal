@echo off
:: ============================================================
::  SOC Arsenal — Portable Launcher (Windows)
::  Fully portable: no admin required, no install needed.
::  Just copy the folder and double-click run.bat
:: ============================================================
setlocal EnableDelayedExpansion
cd /d "%~dp0"

set "LIB=%~dp0lib_win"
set "FLAG=%~dp0.lib_win_ready"
set "LOGFILE=%~dp0setup_log.txt"

echo.
echo ============================================================
echo          SOC Arsenal -- Portable Launcher
echo ============================================================
echo.

:: ── Step 1: Find Python 3.9+ ──────────────────────────────────────────────
set "PYTHON="
for %%P in (
    "%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python310\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python39\python.exe"
    "%APPDATA%\Python\Python313\Scripts\python.exe"
    "python"
    "python3"
) do (
    if "!PYTHON!"=="" (
        where %%~P >nul 2>&1 && set "PYTHON=%%~P"
        if "!PYTHON!"=="" (
            if exist %%P (set "PYTHON=%%~P")
        )
    )
)

:: Also try 'python' from PATH
if "!PYTHON!"=="" (
    python --version >nul 2>&1 && set "PYTHON=python"
)
if "!PYTHON!"=="" (
    python3 --version >nul 2>&1 && set "PYTHON=python3"
)

if "!PYTHON!"=="" (
    echo [ERROR] Python 3.9+ not found.
    echo.
    echo Please install Python WITHOUT admin rights:
    echo   1. Go to: https://www.python.org/downloads/windows/
    echo   2. Download Python 3.11+ installer
    echo   3. Run installer and select "Install for current user only"
    echo      (Do NOT check "Install for all users")
    echo.
    pause
    exit /b 1
)

:: Verify version >= 3.9
for /f %%V in ('!PYTHON! -c "import sys; print(sys.version_info.major * 100 + sys.version_info.minor)" 2^>nul') do set PYVER=%%V
if !PYVER! LSS 309 (
    echo [ERROR] Python 3.9+ required. Found version too old.
    pause
    exit /b 1
)

for /f "tokens=*" %%V in ('!PYTHON! --version 2^>^&1') do echo [OK] %%V
echo [*]  Path: !PYTHON!
echo.

:: ── Step 2: Check if lib_win/ is ready ───────────────────────────────────
set "NEEDS_SETUP=0"
if not exist "!FLAG!" set "NEEDS_SETUP=1"
if not exist "!LIB!" set "NEEDS_SETUP=1"

if "!NEEDS_SETUP!"=="1" (
    echo [*] Setting up portable libraries (first run only, ~2-3 min)...
    echo     This needs internet access. Please wait.
    echo.
    
    if not exist "!LIB!" mkdir "!LIB!"
    
    echo     [1/3] Upgrading pip...
    !PYTHON! -m pip install --upgrade pip --quiet --user 2>nul
    
    echo     [2/3] Installing base packages...
    !PYTHON! -m pip install ^
        PyQt6 ^
        pynput ^
        pyperclip ^
        requests ^
        jinja2 ^
        typing_extensions ^
        diskcache ^
        numpy ^
        keyboard ^
        openpyxl ^
        ddgs ^
        beautifulsoup4 ^
        curl_cffi ^
        --target="!LIB!" ^
        --upgrade --quiet ^
        --no-warn-script-location ^
        >> "!LOGFILE!" 2>&1
    
    if errorlevel 1 (
        echo     [!] Base packages install failed. Check setup_log.txt
        pause
        exit /b 1
    )
    echo     [OK] Base packages installed.
    
    echo     [3/3] Installing AI backend (llama-cpp-python)...
    echo           Trying GPU-accelerated build first...
    
    :: Try Vulkan (works for NVIDIA, AMD, Intel on Windows)
    !PYTHON! -m pip install "llama-cpp-python" ^
        --prefer-binary ^
        --extra-index-url https://abetlen.github.io/llama-cpp-python/whl/vulkan ^
        --target="!LIB!" ^
        --upgrade --quiet ^
        --no-warn-script-location ^
        >> "!LOGFILE!" 2>&1
    
    !PYTHON! -c "import sys; sys.path.insert(0,'!LIB!'); import llama_cpp" >nul 2>&1
    if errorlevel 1 (
        echo           Vulkan failed. Trying CPU fallback...
        !PYTHON! -m pip install "llama-cpp-python" ^
            --prefer-binary ^
            --target="!LIB!" ^
            --upgrade --quiet ^
            --no-warn-script-location ^
            >> "!LOGFILE!" 2>&1
    ) else (
        echo     [OK] AI backend (Vulkan GPU) installed.
    )
    
    echo !PYTHON! > "!FLAG!"
    echo.
    echo [OK] First-time setup complete!
    echo.
)

:: ── Step 3: Check for AI model ────────────────────────────────────────────
set "HAS_MODEL=0"
for %%F in ("%~dp0*.gguf") do set "HAS_MODEL=1"
if "!HAS_MODEL!"=="0" (
    echo [!] No .gguf model found.
    echo     Place a .gguf file next to run.bat, or use Tray Menu to download one.
    echo.
)

:: ── Step 4: Launch App ────────────────────────────────────────────────────
echo [*] Starting SOC Arsenal...
echo.

set "PYTHONPATH=!LIB!"
!PYTHON! "%~dp0app.py"

if errorlevel 1 (
    echo.
    echo [!] App exited with an error.
    echo     To reset: delete .lib_win_ready and run.bat again.
    pause
)
