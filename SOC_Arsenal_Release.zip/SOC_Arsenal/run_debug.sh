#!/bin/bash
# ============================================================
#  SOC Arsenal — macOS Quick Launch (after first-time setup)
# ============================================================

set -e
cd "$(dirname "$0")"

BOLD='\033[1m'
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m'

echo ""
echo "============================================"
echo "   SOC Arsenal - Debug Launcher (macOS)"
echo "============================================"

# Find Python
PYTHON=""
for cmd in python3 python; do
    if command -v "$cmd" &>/dev/null; then
        VER=$("$cmd" -c "import sys; print(sys.version_info.major)")
        if [ "$VER" -ge 3 ]; then
            PYTHON="$cmd"
            break
        fi
    fi
done

if [ -z "$PYTHON" ]; then
    echo -e "${RED}[ERROR] Python not found!${NC}"
    echo "Run setup.sh first."
    exit 1
fi

echo -e "${GREEN}[OK] Found Python: $PYTHON${NC}"
echo ""

"$PYTHON" app.py
echo ""
echo "Press Enter to close..."
read
