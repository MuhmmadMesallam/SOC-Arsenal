# SOC Arsenal — Portable Edition

## 🚀 Quick Start

### macOS
```bash
./run.sh
```

### Windows
```
Double-click run.bat
```
> No admin rights required. Python must be installed for current user.

---

## 📋 Requirements

| | macOS | Windows |
|---|---|---|
| **OS** | macOS 12+ (Apple Silicon or Intel) | Windows 10/11 (x64) |
| **Python** | Built-in 3.9 or Homebrew 3.13 | Python 3.9–3.13 (user install) |
| **Admin** | ❌ Not needed | ❌ Not needed |
| **Internet** | First run only | First run only |
| **Disk space** | ~700MB (`lib/` + model) | ~700MB (`lib_win/` + model) |

---

## 🤖 AI Model (.gguf)
The AI model is **NOT included** (4.7GB). You have two options:

**Option A — Copy your model:**
Place a `.gguf` file next to `run.sh` / `run.bat`:
```
SOC_Arsenal_MACOS/
├── run.sh          ← macOS launcher
├── run.bat         ← Windows launcher
├── your_model.gguf ← copy here
```

**Option B — Download via app:**
Launch the app → Tray icon → "Download AI Model"

---

## 🔁 First Run Behavior

On a **new machine**, the launcher will:
1. Detect your Python version
2. Auto-install all packages into `lib/` or `lib_win/` (~2 min)
3. Start the app immediately

This only happens **once**. Subsequent runs start instantly.

---

## 🪟 Windows — Installing Python (No Admin)

1. Go to: https://www.python.org/downloads/windows/
2. Download Python 3.11 or 3.13 installer
3. Run installer → **Important:** check **"Add Python to PATH"**
4. Select **"Install for current user only"** (no admin needed)
5. Run `run.bat`

---

## 🍎 macOS — Accessibility Permission

For Ctrl+Shift+X hotkey to work:
> System Settings → Privacy & Security → Accessibility → Add Terminal ✓

---

## 📁 Folder Structure

```
SOC_Arsenal_MACOS/
├── run.sh              ← macOS launcher
├── run.bat             ← Windows launcher
├── app.py              ← Main application
├── lib/                ← macOS packages (auto-built)
├── lib_win/            ← Windows packages (auto-built)
├── .lib_ready          ← macOS build marker
├── .lib_win_ready      ← Windows build marker
├── *.gguf              ← AI model (add manually)
├── ti_config.json      ← API keys (auto-saved)
└── icon.png
```

## 🔄 Transferring to a New Machine

1. Copy the entire folder (USB / cloud / AirDrop)
2. Add your `.gguf` model file
3. Run `run.sh` (macOS) or `run.bat` (Windows)

> **Tip:** Include the `lib/` or `lib_win/` folder to skip first-run setup (~350MB extra)

## ♻️ Reset Portable Setup
```bash
# macOS
rm .lib_ready && ./run.sh

# Windows (Command Prompt)
del .lib_win_ready && run.bat
```
