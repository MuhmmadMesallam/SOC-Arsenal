#!/bin/bash
# ============================================================
#  SOC Arsenal — Protected Launcher (macOS)
#  Code is obfuscated — source not readable.
# ============================================================
cd "$(dirname "$0")"

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BOLD='\033[1m'; NC='\033[0m'
LIB="$(pwd)/lib"
APP="$(pwd)/protected_dist/app.py"

# Find Python 3.9 (required for PyArmor runtime)
PYTHON=""
for cmd in python3.9 python3 python; do
    if command -v "$cmd" &>/dev/null 2>&1; then
        VER=$("$cmd" -c "import sys; print(sys.version_info.major*100+sys.version_info.minor)" 2>/dev/null)
        if [ -n "$VER" ] && [ "$VER" -ge 309 ]; then
            PYTHON="$cmd"; break
        fi
    fi
done

if [ -z "$PYTHON" ]; then
    echo "ERROR: Python 3.9+ required."; exit 1
fi

echo -e "${BOLD}SOC Arsenal — Protected Edition${NC}"
echo -e "${GREEN}$($PYTHON --version 2>&1)${NC}"

PYTHONPATH="$LIB:$(pwd)/protected_dist" "$PYTHON" "$APP"
